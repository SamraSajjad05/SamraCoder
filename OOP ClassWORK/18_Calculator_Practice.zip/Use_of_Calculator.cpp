#include <iostream>
using namespace std;

int main()
{
	int a ;
		int b ;
	cout << "enter a nmb";
	cin >> a;
	cout << "entr an other ";
	cin >> b;
	cout << "the addition of the nmbers is " << a + b << endl;
	cout << "the mull of two nmbers is " << a * b << endl;
	cout << "the subtraction of two nmbers is" << a-b << endl;
	cout << " the division of two nmbers is " << a / b << endl;
	return 0;
}